const mysql = require('mysql');

const con = mysql.createConnection({
    host: "awseb-e-ia3n54nvdq-stack-awsebrdsdatabase-cj5edgon8nja.cxdiure1h4ew.us-east-1.rds.amazonaws.com",
    user: "admin",
    database: "ebdb",
    port: "3306",
    password: "admin12345",
    connectionLimit: 15,
    queueLimit: 30,
    acquireTimeout: 1000000
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});
module.exports=con;